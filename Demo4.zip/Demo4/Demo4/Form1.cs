﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo4
{
    public partial class Form1 : Form
    {
        List<Jugador> jugadores = new List<Jugador>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            /*jugadores.Add(new Jugador() { Nombre = "Obando", Puntaje = 13 });
            jugadores.Add(new Jugador() { Nombre = "Mario", Puntaje = 22 });
            jugadores.RemoveAt(0);
            List<Jugador> jugadoresOrdenadosAsc = jugadores.OrderBy(s => s.Puntaje).ToList();
            List<Jugador> jugadoresOrdenadosDesc = jugadores.OrderByDescending(s=> s.Nombre).ToList();

            int puntajeMax= jugadores.Max(x=> x.Puntaje);
            int puntajeMin = jugadores.Min(x=> x.Puntaje);
            double promedio = jugadores.Average(x=> x.Puntaje);
            */
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            jugadores.Add(new Jugador() { Nombre = txtNombre.Text, Puntaje = (int)numPuntaje.Value });
            UpdateGrid();
        }
        private void UpdateGrid()
        {
            dgListaOriginal.DataSource = jugadores.ToList();           
            lbCountOriginal.Text = jugadores.Count.ToString();
            dgAsc.DataSource = jugadores.OrderBy(s => s.Nombre).ToList();
            Random random = new Random();
            dgAleatoria.DataSource = jugadores.OrderBy(s => random.Next()).ToList();
            txtMaximo.Text = jugadores.Max(s=> s.Puntaje).ToString();
            txtMinimo.Text = jugadores.Min(s=> s.Puntaje).ToString();
            txtPromedio.Text = jugadores.Average(s => s.Puntaje).ToString();
        }
    }
}
