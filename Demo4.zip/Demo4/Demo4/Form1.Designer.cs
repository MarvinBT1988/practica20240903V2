﻿namespace Demo4
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgListaOriginal = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.lbCountOriginal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numPuntaje = new System.Windows.Forms.NumericUpDown();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.dgAsc = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.dgAleatoria = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.lbPuntajeMaximo = new System.Windows.Forms.Label();
            this.txtMaximo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMinimo = new System.Windows.Forms.TextBox();
            this.txtPromedio = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgListaOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPuntaje)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAsc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAleatoria)).BeginInit();
            this.SuspendLayout();
            // 
            // dgListaOriginal
            // 
            this.dgListaOriginal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgListaOriginal.Location = new System.Drawing.Point(12, 223);
            this.dgListaOriginal.Name = "dgListaOriginal";
            this.dgListaOriginal.Size = new System.Drawing.Size(300, 132);
            this.dgListaOriginal.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lista Original";
            // 
            // lbCountOriginal
            // 
            this.lbCountOriginal.AutoSize = true;
            this.lbCountOriginal.Location = new System.Drawing.Point(288, 196);
            this.lbCountOriginal.Name = "lbCountOriginal";
            this.lbCountOriginal.Size = new System.Drawing.Size(12, 13);
            this.lbCountOriginal.TabIndex = 3;
            this.lbCountOriginal.Text = "x";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(86, 45);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(274, 20);
            this.txtNombre.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Puntaje";
            // 
            // numPuntaje
            // 
            this.numPuntaje.Location = new System.Drawing.Point(86, 77);
            this.numPuntaje.Name = "numPuntaje";
            this.numPuntaje.Size = new System.Drawing.Size(161, 20);
            this.numPuntaje.TabIndex = 7;
            // 
            // btnInsertar
            // 
            this.btnInsertar.Location = new System.Drawing.Point(28, 120);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(98, 33);
            this.btnInsertar.TabIndex = 8;
            this.btnInsertar.Text = "Insertar";
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // dgAsc
            // 
            this.dgAsc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAsc.Location = new System.Drawing.Point(355, 223);
            this.dgAsc.Name = "dgAsc";
            this.dgAsc.Size = new System.Drawing.Size(300, 132);
            this.dgAsc.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(352, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Lista  ordenado Asc por nombre";
            // 
            // dgAleatoria
            // 
            this.dgAleatoria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAleatoria.Location = new System.Drawing.Point(708, 223);
            this.dgAleatoria.Name = "dgAleatoria";
            this.dgAleatoria.Size = new System.Drawing.Size(300, 132);
            this.dgAleatoria.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(705, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Lista Aleatoria";
            // 
            // lbPuntajeMaximo
            // 
            this.lbPuntajeMaximo.AutoSize = true;
            this.lbPuntajeMaximo.Location = new System.Drawing.Point(118, 387);
            this.lbPuntajeMaximo.Name = "lbPuntajeMaximo";
            this.lbPuntajeMaximo.Size = new System.Drawing.Size(0, 13);
            this.lbPuntajeMaximo.TabIndex = 16;
            // 
            // txtMaximo
            // 
            this.txtMaximo.Enabled = false;
            this.txtMaximo.Location = new System.Drawing.Point(134, 390);
            this.txtMaximo.Name = "txtMaximo";
            this.txtMaximo.Size = new System.Drawing.Size(134, 20);
            this.txtMaximo.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 390);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Puntaje Maximo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 434);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Puntaje minimo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 477);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Promedio puntajes";
            // 
            // txtMinimo
            // 
            this.txtMinimo.Enabled = false;
            this.txtMinimo.Location = new System.Drawing.Point(134, 431);
            this.txtMinimo.Name = "txtMinimo";
            this.txtMinimo.Size = new System.Drawing.Size(134, 20);
            this.txtMinimo.TabIndex = 22;
            // 
            // txtPromedio
            // 
            this.txtPromedio.Enabled = false;
            this.txtPromedio.Location = new System.Drawing.Point(134, 474);
            this.txtPromedio.Name = "txtPromedio";
            this.txtPromedio.Size = new System.Drawing.Size(134, 20);
            this.txtPromedio.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1352, 605);
            this.Controls.Add(this.txtPromedio);
            this.Controls.Add(this.txtMinimo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMaximo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbPuntajeMaximo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgAleatoria);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgAsc);
            this.Controls.Add(this.btnInsertar);
            this.Controls.Add(this.numPuntaje);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbCountOriginal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgListaOriginal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgListaOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPuntaje)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAsc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAleatoria)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgListaOriginal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbCountOriginal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numPuntaje;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.DataGridView dgAsc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgAleatoria;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbPuntajeMaximo;
        private System.Windows.Forms.TextBox txtMaximo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMinimo;
        private System.Windows.Forms.TextBox txtPromedio;
    }
}

